package test;

/**
 */
public interface TestCommonInterface {
    
    public String getDisplayString();

}
